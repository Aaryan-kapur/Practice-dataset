# Box

Transfer and sync files from Box.com to data.world.

[Logo]: https://cdn.filepicker.io/api/file/OiiVoJkvT32LOuZA2PH5
[CTA]: https://account.box.com/signup/n/starter "Try it free →"
[Website]: https://box.com
[Documentation]: https://help.data.world
[Support]: https://help.data.world/hc/en-us/requests/new
[GetStarted]: https://datadotworld.github.io/integration-docs/box-com.html

## Description

Securely store, manage and share all your files, photos and documents with cloud storage from Box.

With Box, you can easily:
* Access and work on all your files at your fingertips
* Access your content online, from your desktop, and on your mobile device
* Share important documents, contracts, visuals and more 
* Preview 200+ file types with full screen quality
* Give feedback from anywhere by commenting and mentioning colleagues and partners 

On data.world it's easy to add and automatically sync files from Box to your datasets and data projects.
